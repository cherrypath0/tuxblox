#
# Configuration file for using the xslt library
#
XSLT_LIBDIR="-L/opt/tuxblox-webview/lib"
XSLT_LIBS="-lxslt -L/opt/tuxblox-webview/lib/x86_64-linux-gnu -lxml2 "
XSLT_PRIVATE_LIBS="-lm"
XSLT_INCLUDEDIR="-I/opt/tuxblox-webview/include"
MODULE_VERSION="xslt-1.1.45"
